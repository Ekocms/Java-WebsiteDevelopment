/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50738
Source Host           : localhost:3306
Source Database       : cos

Target Server Type    : MYSQL
Target Server Version : 50738
File Encoding         : 65001

Date: 2022-07-06 21:47:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_appointment`
-- ----------------------------
DROP TABLE IF EXISTS `t_appointment`;
CREATE TABLE `t_appointment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `appt_num` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单号',
  `reserve_id` bigint(20) DEFAULT NULL COMMENT '订单id',
  `dish_id` bigint(20) DEFAULT NULL COMMENT '菜品id',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户id',
  `fee` decimal(10,2) DEFAULT NULL COMMENT '费用',
  `status` int(11) DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `reserve_num` (`reserve_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of t_appointment
-- ----------------------------
INSERT INTO `t_appointment` VALUES ('1', '1001', '1', '1', '1', '25.00', '1');
INSERT INTO `t_appointment` VALUES ('2', '1002', '2', '4', '1', '32.50', '1');
INSERT INTO `t_appointment` VALUES ('3', '1003', '3', '6', '2', '95.50', '1');
INSERT INTO `t_appointment` VALUES ('4', '1004', '4', '2', '3', '20.00', '1');
INSERT INTO `t_appointment` VALUES ('5', '1005', '5', '5', '3', '43.50', '2');
INSERT INTO `t_appointment` VALUES ('6', '947465', '3', '6', '3', '95.50', '1');
INSERT INTO `t_appointment` VALUES ('7', '801962', '3', '6', '3', '95.50', '1');

-- ----------------------------
-- Table structure for `t_community`
-- ----------------------------
DROP TABLE IF EXISTS `t_community`;
CREATE TABLE `t_community` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `code` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '代码',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '社区名称',
  `address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `brief` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '简介',
  PRIMARY KEY (`id`),
  KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of t_community
-- ----------------------------
INSERT INTO `t_community` VALUES ('1', '2001', '望都家园', '北京市昌平区定泗路', '小区位于亚运村正北10公里，社区服务中心、幼儿园等配套设施一应俱全。');
INSERT INTO `t_community` VALUES ('2', '2002', '金色漫香苑', '北京市昌平区天权路2号', '作为区域内唯一花园洋房，是中央别墅间最后的珍稀土地，近邻300亩海青落湖公园。');
INSERT INTO `t_community` VALUES ('3', '2003', '王府温馨公寓', '北京市昌平区七北路', '东北辽阔的垂钓水面，使饱享自然恩泽的王府温馨公寓，以天蓝、水清、空气清新的人居环境成为现代理想的养生居所。');
INSERT INTO `t_community` VALUES ('4', '2004', '桃园公寓', '北京市昌平区北七家', '以大户型小社区安逸静谧，赢得了著名各企事业单位以及各界成功人士的青睐。');

-- ----------------------------
-- Table structure for `t_dish`
-- ----------------------------
DROP TABLE IF EXISTS `t_dish`;
CREATE TABLE `t_dish` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `comm_code` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '社区代码',
  `name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品名称',
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品类型',
  `fee` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `brief` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '简介',
  PRIMARY KEY (`id`),
  KEY `comm_code` (`comm_code`),
  CONSTRAINT `comm_code` FOREIGN KEY (`comm_code`) REFERENCES `t_community` (`code`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of t_dish
-- ----------------------------
INSERT INTO `t_dish` VALUES ('1', '2001', '三鲜饺子', '饺子馄饨', '25.00', '一份20个皮薄馅大');
INSERT INTO `t_dish` VALUES ('2', '2001', '招牌牛肉饭', '快餐便当', '20.00', '牛肉洋葱饭便宜大碗');
INSERT INTO `t_dish` VALUES ('3', '2002', '皮蛋瘦肉粥', '包子粥店', '9.50', '不需要过多解释');
INSERT INTO `t_dish` VALUES ('4', '2003', '巨无霸汉堡', '汉堡薯条', '32.50', '痞老板日夜思念的秘制配方大汉堡');
INSERT INTO `t_dish` VALUES ('5', '2003', '夏威夷披萨', '意面披萨', '43.50', '5寸意大利人不喜欢但备受国人喜爱的异国风情披萨');
INSERT INTO `t_dish` VALUES ('6', '2003', '黑椒牛排', '能量西餐', '95.50', '高端大气上档次');
INSERT INTO `t_dish` VALUES ('7', '2002', '招牌米粉', '米粉面馆', '23.50', '妈妈的味道');
INSERT INTO `t_dish` VALUES ('9', '2002', '韭菜鸡蛋', '炒菜', '23.40', '熟悉的味道');
INSERT INTO `t_dish` VALUES ('10','2001', '干炸里脊', '油炸', '10.90', '油滋滋，香喷喷');
INSERT INTO `t_dish` VALUES ('11','2001', '碳烤洋葱', '烧烤', '3.00', '香香的感觉让人沉醉');
INSERT INTO `t_dish` VALUES ('12','2004', '黑椒牛柳', '炒菜', '34.00', '麻辣味，够劲！');
INSERT INTO `t_dish` VALUES ('13','2004', '西红柿鸡蛋', '炒菜', '23.99', '纯正绿色有机西红柿！');
INSERT INTO `t_dish` VALUES ('14','2004', '喜之郎烤羊排', '烧烤', '188.88', '当日现杀小羊');
INSERT INTO `t_dish` VALUES ('15','2004', '天津小笼包', '包子', '10.00', '正宗天津小笼包十块钱八个！');

-- ----------------------------
-- Table structure for `t_reserve_info`
-- ----------------------------
DROP TABLE IF EXISTS `t_reserve_info`;
CREATE TABLE `t_reserve_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `reserve_num` int(11) DEFAULT NULL COMMENT '订单序号',
  `dish_id` bigint(20) DEFAULT NULL COMMENT '菜品id',
  `reserve_datetime` datetime DEFAULT NULL COMMENT '订单日期',
  `reserve_period` int(11) DEFAULT NULL COMMENT '出餐时间，单位分钟，如15表示15分钟出餐',
  `expence` decimal(10,2) DEFAULT NULL COMMENT '订单金额',
  `status` int(11) DEFAULT NULL COMMENT '订单状态',
  PRIMARY KEY (`id`),
  KEY `reserve_num` (`reserve_num`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of t_reserve_info
-- ----------------------------
INSERT INTO `t_reserve_info` VALUES ('1', '3001', '1', '2022-06-27 22:02:12', '15', '25.00', '2');
INSERT INTO `t_reserve_info` VALUES ('2', '3002', '4', '2022-06-28 11:46:03', '30', '32.50', '1');
INSERT INTO `t_reserve_info` VALUES ('3', '3003', '6', '2022-06-29 12:15:36', '45', '95.50', '2');
INSERT INTO `t_reserve_info` VALUES ('4', '3004', '2', '2022-06-30 08:30:23', '25', '20.00', '2');
INSERT INTO `t_reserve_info` VALUES ('5', '3005', '5', '2022-06-30 16:24:44', '30', '43.50', '2');

-- ----------------------------
-- Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户名',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '显示名',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `registration_date` date DEFAULT NULL COMMENT '注册日期',
  `user_level` int(11) DEFAULT NULL COMMENT '用户等级',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', '安诣暄', '安诣暄', '0629', '2022-06-25', '1', '2022-06-29 10:45:08');
INSERT INTO `t_user` VALUES ('2', '王五', '王五', '123456', '2022-06-26', '0', '2022-07-05 09:15:23');
INSERT INTO `t_user` VALUES ('3', 'admin', 'admin', '123', '2022-06-27', '2', '2022-06-27 07:50:31');
