package com.example.firstdemo331.repository;

import com.example.firstdemo331.entity.User;

public interface UserDao extends BaseDao<User, Long> {

    /**根据userName 查询 user 数据*/
    User findByUserName(String userName);

//	User findById(long id);

//	User findByUserNameAndName(String userName, String name);

}
