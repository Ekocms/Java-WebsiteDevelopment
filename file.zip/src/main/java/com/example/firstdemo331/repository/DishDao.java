package com.example.firstdemo331.repository;

import com.example.firstdemo331.entity.Dish;

public interface DishDao extends BaseDao<Dish, Long> {
}
