package com.example.firstdemo331.repository;

import com.example.firstdemo331.entity.Community;

public interface CommunityDao extends BaseDao<Community, Long> {
}
