package com.example.firstdemo331.repository;

import com.example.firstdemo331.entity.ReserveInfo;

public interface ReserveInfoDao extends BaseDao<ReserveInfo, Long> {
}
