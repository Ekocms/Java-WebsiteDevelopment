package com.example.firstdemo331.repository;

import com.example.firstdemo331.entity.Appointment;

public interface AppointmentDao extends BaseDao<Appointment, Long> {
}
