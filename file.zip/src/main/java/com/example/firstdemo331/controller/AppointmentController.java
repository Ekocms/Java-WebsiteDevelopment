package com.example.firstdemo331.controller;

import com.example.firstdemo331.entity.Appointment;
import com.example.firstdemo331.entity.Community;
import com.example.firstdemo331.entity.ReserveInfo;
import com.example.firstdemo331.entity.User;
import com.example.firstdemo331.service.AppointmentService;
import com.example.firstdemo331.service.ReserveInfoService;
import com.example.firstdemo331.service.UserService;
import com.example.firstdemo331.utils.Constant;
import com.example.firstdemo331.utils.Servlets;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * 预约处理Controller
 */
@Controller
@RequestMapping(value = "/web/appointment")
public class AppointmentController {

    /**
     * 预约处理Servicec注入
     */
    @Autowired
    private AppointmentService appointmentService;

    /**
     * 预约订餐Servicec注入
     */
    @Autowired
    private ReserveInfoService reserveInfoService;

    /**
     * 用户Servicec注入
     */
    @Autowired
    private UserService userService;

    /**
     * 发起预约
     * @param id
     * @param request
     * @return
     */
    @ResponseBody //返回 json 数据
    @ApiOperation(httpMethod = "POST", value = "创建", notes = "")
    @RequestMapping(value = "create/{id}", method = RequestMethod.POST)
    public Map<String, Object> create(@PathVariable("id") Long id, HttpServletRequest request) {
        Map<String, Object> map = new HashMap<>();
        try {
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");
            if (user == null) {
                map.put("code", "500");
                map.put("message", "没有用户信息");
                return map;
            }
            //不是查出来的 user 所以 必须 查一下
            user = userService.findByUserName(user.getUserName());
            ReserveInfo reserveInfo = reserveInfoService.get(id);
            try {
                appointmentService.create(reserveInfo, user);
            } catch (Exception e) {
                e.printStackTrace();
            }
            map.put("code", "200");
            map.put("message", "预约成功");
            return map;
        } catch (Exception e) {
            map.put("code", "500");
            map.put("message", "预约失败");
            e.getMessage();
            return map;
        }
    }

    /**
     * 我的预约列表——带分页查询
     * @param pageNumber
     * @param pageSize
     * @param sortType
     * @param request
     * @param model
     * @return
     */
    @ApiOperation(value = "分页", notes = "")
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    public String page(@RequestParam(value = "page", defaultValue = "1") int pageNumber,
                       @RequestParam(value = "page.size", defaultValue = Constant.PAGE_SIZE) int pageSize,
                       @RequestParam(value = "sortType", defaultValue = "auto") String sortType, HttpServletRequest request,
                       Model model) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "login";
        }
//        Page<Appointment> page = appointmentService.getPage(pageNumber, pageSize, sortType);
//        model.addAttribute("list", page);
//        return "appointment/list";
//    }
        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Appointment> page = appointmentService.getPage(searchParams,pageNumber, pageSize, sortType);
        model.addAttribute("list", page);
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "/appointment/list";
    }

    /**
     * 注册方法
     * @param model
     * @return
     */
    @ApiOperation(httpMethod = "POST", value = "创建")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public String create(Appointment model) {
        //业务逻辑在这补  比如判断账号 是否存在
        appointmentService.save(model);
        //注册成功后 这要重定向到哪个方法 这里 又访问了 登录的路由
        return "redirect:/web/appointment/page";
    }

    @ApiOperation(httpMethod = "POST", value = "创建")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(Appointment model) {
        //业务逻辑在这补  比如判断账号 是否存在
        appointmentService.save(model);
        //注册成功后 这要重定向到哪个方法 这里 又访问了 登录的路由
        return "redirect:/web/appointment/page";
    }

    @ApiOperation(httpMethod = "GET", value = "删除")
    @RequestMapping(value = "/del/{id}", method = RequestMethod.GET)
    public String del(@PathVariable("id") Long id,Model model) {
        Appointment appointment = appointmentService.get(id);
        appointmentService.delete(appointment);
        return "redirect:/web/appointment/page";
    }

    @ApiOperation(httpMethod = "GET", value = "路由跳转登录页面")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public String list(Model model) {
        List<Appointment> list = appointmentService.getAll();
        model.addAttribute("list", list);
        return "/appointment/list";
    }

}

