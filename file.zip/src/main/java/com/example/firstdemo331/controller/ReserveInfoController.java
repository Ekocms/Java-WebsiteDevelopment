package com.example.firstdemo331.controller;


import com.example.firstdemo331.entity.ReserveInfo;
import com.example.firstdemo331.entity.User;
import com.example.firstdemo331.service.ReserveInfoService;
import com.example.firstdemo331.utils.Constant;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping(value = "/web/reserveInfo")
public class ReserveInfoController {
    /**
     * 订单信息Service
     */
    @Autowired
    private ReserveInfoService reserveInfoService;

    /**
     * 列表查询
     * @return
     */
    @ApiOperation(value = "分页", notes = "")
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    public String page(@RequestParam(value = "page", defaultValue = "1") int pageNumber,
                       @RequestParam(value = "page.size", defaultValue = Constant.PAGE_SIZE) int pageSize,
                       @RequestParam(value = "sortType", defaultValue = "auto") String sortType, HttpServletRequest request,
                       Model model) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "login";
        }

        Page<ReserveInfo> page = reserveInfoService.getPage(pageNumber, pageSize, sortType);
        model.addAttribute("list", page);
        return "reserveInfo/list";
    }
}

