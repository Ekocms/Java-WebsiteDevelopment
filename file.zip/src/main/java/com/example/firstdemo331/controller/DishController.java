package com.example.firstdemo331.controller;

import com.example.firstdemo331.entity.Dish;
import com.example.firstdemo331.entity.User;
import com.example.firstdemo331.service.DishService;
import com.example.firstdemo331.utils.Constant;
import com.example.firstdemo331.utils.Servlets;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.*;


@Controller
@RequestMapping(value = "/web/dish")
public class DishController {
    /**
     * 菜品Servicec注入
     */
    @Autowired
    private DishService dishService;

    /**
     * 菜品列表
     * @return
     */
    @ApiOperation(value = "分页", notes = "")
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    public String page(@RequestParam(value = "page", defaultValue = "1") int pageNumber,
                       @RequestParam(value = "page.size", defaultValue = Constant.PAGE_SIZE) int pageSize,
                       @RequestParam(value = "sortType", defaultValue = "auto") String sortType, HttpServletRequest request,
                       Model model) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "login";
        }

//        Page<Dish> page = dishService.getPage(pageNumber, pageSize, sortType);
//        model.addAttribute("list", page);
//        model.addAttribute("date", getDay());
//        return "dish/list";
//    }

        Map<String, Object> searchParams = Servlets.getParametersStartingWith(request, "search_");
        Page<Dish> page = dishService.getPage(searchParams,pageNumber, pageSize, sortType);
        model.addAttribute("list", page);
        model.addAttribute("date", getDay());
        model.addAttribute("searchParams", Servlets.encodeParameterStringWithPrefix(searchParams, "search_"));
        return "/dish/list";
    }

    /**
     * 获取后一天
     * @return
     */
    private String getDay() {
        // 取时间
        Date date = new Date();
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        // 把日期往后增加一天,整数  往后推,负数往前移动
        calendar.add(Calendar.DATE, 1);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = format.format(calendar.getTime());
        return dateString;
    }
    @ApiOperation(httpMethod = "GET", value = "路由跳转登录页面")
    @RequestMapping(value = "/input", method = RequestMethod.GET)
    public String input(Model model) {
        model.addAttribute("action", "create");
        return "/dish/input";
    }

    @ApiOperation(httpMethod = "GET", value = "路由跳转登录页面")
    @RequestMapping(value = "/input/{id}", method = RequestMethod.GET)
    public String update(@PathVariable("id") Long id, Model model) {
        Dish dish = dishService.get(id);
        model.addAttribute("model", dish);
        model.addAttribute("action", "update");
        return "/dish/input";
    }

    @ApiOperation(httpMethod = "GET", value = "详情页面")
    @RequestMapping(value = "/show/{id}", method = RequestMethod.GET)
    public String show(@PathVariable("id") Long id,Model model) {
        Dish dish = dishService.get(id);
        model.addAttribute("model", dish);
        return "/dish/show";
    }

    /**
     * 注册方法
     * @param model
     * @return
     */
    @ApiOperation(httpMethod = "POST", value = "创建")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public String create(Dish model) {
        //业务逻辑在这补  比如判断账号 是否存在
        dishService.save(model);
        //注册成功后 这要重定向到哪个方法 这里 又访问了 登录的路由
        return "redirect:/web/dish/page";
    }

    @ApiOperation(httpMethod = "POST", value = "创建")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(Dish model) {
        //业务逻辑在这补  比如判断账号 是否存在
        dishService.save(model);
        //注册成功后 这要重定向到哪个方法 这里 又访问了 登录的路由
        return "redirect:/web/dish/page";
    }

    @ApiOperation(httpMethod = "GET", value = "删除")
    @RequestMapping(value = "/del/{id}", method = RequestMethod.GET)
    public String del(@PathVariable("id") Long id,Model model) {
        Dish dish = dishService.get(id);
        dishService.delete(dish);
        return "redirect:/web/dish/page";
    }

    @ApiOperation(httpMethod = "GET", value = "路由跳转登录页面")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public String list(Model model) {
        List<Dish> list = dishService.getAll();
        model.addAttribute("list", list);
        return "/dish/list";
    }
}

