package com.example.firstdemo331.utils;

public class Constant {
    public static final String PAGE_SIZE = "5";
}
