package com.example.firstdemo331.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

@Entity
@Table(name = "t_reserve_info")
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
public class ReserveInfo extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -8279040545030076313L;

    //订单序号
    @Column(name = "reserve_num")
    private int reserveNum;

    //菜品id
    @ManyToOne
    @JoinColumn(name = "dish_id", referencedColumnName = "id", nullable = false)
    private Dish dish;

    //订单日期
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "reserve_datetime")
    private Date reserveDatetime;

    //出餐时间，单位分钟，如15表示15分钟出餐
    @Column(name = "reserve_period")
    private int reservePeriod;

    //订单金额
    @Column(name = "expence")
    private BigDecimal expence;


    //订单状态
    @Column(name = "status")
    private int status;

    public Date getReservePeriodDate() {
        Date date = new Date(); //取时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(this.reserveDatetime);
        calendar.add(calendar.MINUTE, this.reservePeriod); //把日期往后增加一天,整数往后推,负数往前移动
        return calendar.getTime();
    }

}

