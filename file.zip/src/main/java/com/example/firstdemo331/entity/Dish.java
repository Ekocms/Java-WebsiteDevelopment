package com.example.firstdemo331.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "t_dish")
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
public class Dish extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 3847755628413416989L;

    //社区代码
    @ManyToOne
    @JoinColumn(name = "comm_code", referencedColumnName = "code", nullable = true)
    private Community community;

    //菜品名称
    @Column(name = "name", length = 20)
    private String name;

    //菜品类型
    @Column(name = "type", length = 100)
    private String type;

    //金额
    @Column(name = "fee")
    private BigDecimal fee;

    //简介
    @Column(name = "brief")
    private String brief;

    @OneToMany(mappedBy = "dish", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<ReserveInfo> reserveInfos = new ArrayList<>();

}
