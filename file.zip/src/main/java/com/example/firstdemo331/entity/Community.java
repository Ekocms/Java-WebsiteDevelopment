package com.example.firstdemo331.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "t_community")
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
public class Community extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 8165248754364345263L;

    //代码
    @Column(name = "code", length = 18)
    private String code;

    //社区名称
    @Column(name = "name", length = 100)
    private String name;
    
    //地址
    @Column(name = "address", length = 100)
    private String address;

    //简介
    @Column(name = "brief")
    private String brief;



}
