package com.example.firstdemo331.entity;


import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "t_appointment")
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = false)
public class Appointment extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 3847755628413416989L;

    //订单号
    @Column(name = "appt_num", length = 12)
    private String apptNum;

    //订单id
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "reserve_id", referencedColumnName = "id")
    private ReserveInfo reserveInfo;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "dish_id", referencedColumnName = "id")
    private Dish dish;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    //费用
    @Column(name = "fee")
    private BigDecimal fee;

    //状态
    @Column(name = "status")
    private int status;
}
