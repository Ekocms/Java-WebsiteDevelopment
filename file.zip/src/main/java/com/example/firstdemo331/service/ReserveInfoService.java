package com.example.firstdemo331.service;

import com.example.firstdemo331.entity.ReserveInfo;
import com.example.firstdemo331.repository.ReserveInfoDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

// Spring Bean的标识.
@Component
// 类中所有public函数都纳入事务管理的标识.
@Transactional(rollbackFor = Exception.class)
public class ReserveInfoService extends EntityManager<ReserveInfo, Long> {

    @Autowired
    private ReserveInfoDao dao;

    @Override
    protected JpaRepository<ReserveInfo, Long> getEntityDao() {
        return dao;
    }

    public Page<ReserveInfo> getPage(int pageNumber, int pageSize, String sortType) {
        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
        Page<ReserveInfo> listPage = dao.findAll(pageRequest);
        return listPage;
    }

    /**
     * 创建分页请求.
     */
    private PageRequest buildPageRequest(int pageNumber, int pageSize, String sortType) {
        Sort sort = null;
        //默认 id 排序 可以 按照 需求 调整
        if ("auto".equals(sortType)) {
            sort = Sort.by(Sort.Order.desc("id"));
        }
        return PageRequest.of(pageNumber - 1, pageSize, sort);
    }

}

