package com.example.firstdemo331.service;


import com.example.firstdemo331.entity.User;
import com.example.firstdemo331.repository.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

//Spring Bean的标识.
@Component
//类中所有public函数都纳入事务管理的标识.
@Transactional(rollbackFor = Exception.class)
public class UserService extends EntityManager<User, Long> {

    @Autowired
    private UserDao dao;

    public User findByUserName(String userName) {
        return dao.findByUserName(userName);
    }
    
    @Override
    protected JpaRepository<User, Long> getEntityDao() {
        return dao;
    }
}
