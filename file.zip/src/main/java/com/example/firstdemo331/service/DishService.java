package com.example.firstdemo331.service;

import com.example.firstdemo331.entity.Dish;
import com.example.firstdemo331.repository.DishDao;
import com.example.firstdemo331.utils.DynamicSpecifications;
import com.example.firstdemo331.utils.SearchFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Component
// 类中所有public函数都纳入事务管理的标识.
@Transactional(rollbackFor = Exception.class)
public class DishService extends EntityManager<Dish, Long> {

    @Autowired
    private DishDao dao;

    @Override
    protected JpaRepository<Dish, Long> getEntityDao() {
        return dao;
    }

//    public Page<Dish> getPage(int pageNumber, int pageSize, String sortType) {
//        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
//        Page<Dish> listPage = dao.findAll(pageRequest);
//        return listPage;
//    }
    public Page<Dish> getPage( Map<String, Object> searchParams,int pageNumber, int pageSize, String sortType) {
        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
        Specification<Dish> spec = buildSpecification(searchParams);
        return dao.findAll(spec, pageRequest);
    }

    /**
     * 创建分页请求.
     */
    private PageRequest buildPageRequest(int pageNumber, int pageSize, String sortType) {
        Sort sort = null;
        //默认 id 排序 可以 按照 需求 调整
        if ("auto".equals(sortType)) {
            sort = Sort.by(Sort.Order.desc("id"));
        }
        return PageRequest.of(pageNumber - 1, pageSize, sort);
    }

    /**
     * 创建动态查询条件组合. 暂时 没有 添加
     */
    private Specification<Dish> buildSpecification(Map<String, Object> searchParams) {
        Map<String, SearchFilter> filters = SearchFilter.parse(searchParams);
        Specification<Dish> spec = DynamicSpecifications.bySearchFilter(filters.values(), Dish.class);
        return spec;
    }


}

