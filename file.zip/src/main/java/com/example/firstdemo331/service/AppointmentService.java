package com.example.firstdemo331.service;

import com.example.firstdemo331.entity.Appointment;
import com.example.firstdemo331.entity.Community;
import com.example.firstdemo331.entity.ReserveInfo;
import com.example.firstdemo331.entity.User;
import com.example.firstdemo331.repository.AppointmentDao;
import com.example.firstdemo331.repository.ReserveInfoDao;
import com.example.firstdemo331.utils.DynamicSpecifications;
import com.example.firstdemo331.utils.Random;
import com.example.firstdemo331.utils.SearchFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;


// Spring Bean的标识.
@Component
// 类中所有public函数都纳入事务管理的标识.
@Transactional(rollbackFor = Exception.class)
public class AppointmentService extends EntityManager<Appointment, Long> {

    @Autowired
    private AppointmentDao dao;

    @Autowired
    private ReserveInfoDao reserveInfoDao;

    @Override
    protected JpaRepository<Appointment, Long> getEntityDao() {
        return dao;
    }

    public void create(ReserveInfo reserveInfo, User user) {
        Appointment model = new Appointment();
        model.setApptNum(Random.createRandom(true, 6));
        model.setDish(reserveInfo.getDish());
        model.setReserveInfo(reserveInfo);
        model.setFee(reserveInfo.getDish().getFee());
        model.setStatus(1);
        model.setUser(user);
        reserveInfo.setStatus(2);
        //操作两张表 所以放在 service 里 处理  这样 可以 回滚
        reserveInfoDao.save(reserveInfo);
        dao.save(model);
    }

//    public Page<Appointment> getPage(int pageNumber, int pageSize, String sortType) {
//        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
//        Page<Appointment> listPage = dao.findAll(pageRequest);
//        return listPage;
//    }

    public Page<Appointment> getPage(Map<String, Object> searchParams, int pageNumber, int pageSize, String sortType) {
        PageRequest pageRequest = buildPageRequest(pageNumber, pageSize, sortType);
        Specification<Appointment> spec = buildSpecification(searchParams);
        return dao.findAll(spec, pageRequest);
    }

    /**
     * 创建分页请求.
     */
    private PageRequest buildPageRequest(int pageNumber, int pageSize, String sortType) {
        Sort sort = null;
        //默认 id 排序 可以 按照 需求 调整
        if ("auto".equals(sortType)) {
            sort = Sort.by(Sort.Order.desc("id"));
        }
        return PageRequest.of(pageNumber - 1, pageSize, sort);
    }
    private Specification<Appointment> buildSpecification(Map<String, Object> searchParams) {
        Map<String, SearchFilter> filters = SearchFilter.parse(searchParams);
        Specification<Appointment> spec = DynamicSpecifications.bySearchFilter(filters.values(), Appointment.class);
        return spec;
    }


}
